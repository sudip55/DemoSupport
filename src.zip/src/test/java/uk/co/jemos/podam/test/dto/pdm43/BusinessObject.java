/**
 * 
 */
package uk.co.jemos.podam.test.dto.pdm43;

/**
 * @author mtedone
 *
 */
public class BusinessObject<T> {

	//------------------->> Constants

	//------------------->> Instance / Static variables

	//------------------->> Constructors

	//------------------->> Public methods

	// ------------------->> Getters / Setters

	//------------------->> Private methods

	//------------------->> equals() / hashcode() / toString()

	//------------------->> Inner classes

}


