package uk.co.jemos.podam.test.dto;

/**
 * @author divanov
 */
public interface PodamTestInterface {
}
