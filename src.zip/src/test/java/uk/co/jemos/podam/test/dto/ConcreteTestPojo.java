/**
 *
 */
package uk.co.jemos.podam.test.dto;

public class ConcreteTestPojo extends AbstractTestPojo {

}
